package com.example.mobile_development_assignment_two

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
